/* stubs as gif support has been removed */

#include <internal.h> 

image   load_gif(const char *filename)
{
    return (image) NULL;
}

void save_gif(image img, const char *filename)
{
}

